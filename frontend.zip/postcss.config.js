module.exports = {
    plugins: {
        "autoprefixer": {}
    }
};