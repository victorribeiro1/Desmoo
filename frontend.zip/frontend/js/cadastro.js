// JS
import "./cadastro/cadastro"
import "./cadastro/selecaoCategoria"

//SCSS
// import "../scss/cadastro.scss"
