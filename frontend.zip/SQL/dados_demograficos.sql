DROP TABLE IF EXISTS dados_demograficos;
CREATE TABLE IF NOT EXISTS dados_demograficos (
    id_usuario INT NOT NULL,
    

    FOREIGN KEY (id_usuario)
);