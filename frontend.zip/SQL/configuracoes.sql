DROP TABLE IF EXISTS configuracoes;
CREATE TABLE IF NOT EXISTS configuracoes (
    tema ENUM("claro", "escuro") 
);