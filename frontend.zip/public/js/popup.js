/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./frontend/js/popup.js":
/*!******************************!*\
  !*** ./frontend/js/popup.js ***!
  \******************************/
/***/ (function() {

eval("const abrirPopUp = document.getElementById('abrirPopUp')\r\nconst fecharPopUp = document.getElementById('fecharPopUp')\r\nconst popUp = document.getElementById('main')\r\n\r\nconst iconAberto = document.getElementById('iconAberto')\r\nconst iconFechado = document.getElementById('iconFechado')\r\n\r\nabrirPopUp.addEventListener('click', () => {\r\n    popUp.classList.toggle('ativo')\r\n    iconFechado.classList.toggle('ativo')\r\n    iconAberto.classList.toggle('ativo')\r\n\r\n})\r\n\r\nfecharPopUp.addEventListener('click', () => {\r\n    popUp.classList.remove('ativo')\r\n    iconFechado.classList.toggle('ativo')\r\n    iconAberto.classList.toggle('ativo')\r\n})\n\n//# sourceURL=webpack://molde/./frontend/js/popup.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./frontend/js/popup.js"]();
/******/ 	
/******/ })()
;