/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./frontend/js/feed.js":
/*!*****************************!*\
  !*** ./frontend/js/feed.js ***!
  \*****************************/
/***/ (function() {

eval("const alternarComentarios = document.querySelectorAll('.publicacao [alternar-visibiliadade-comentario]')\r\n\r\nfunction alternarVisibilidadeDosComentarios(idPublicacao) {\r\n    const comentarios = document.querySelector(`.publicacao[id-publicacao=\"${idPublicacao}\"] .publicacao__comentarios`)\r\n    \r\n    if (comentarios.classList.contains('ativados')) {\r\n        comentarios.classList.remove('ativados')\r\n    } else {\r\n        comentarios.classList.add('ativados')\r\n    }\r\n}\r\n\r\nalternarComentarios.forEach(alternar => {\r\n    alternar.addEventListener('click', () => {\r\n        alternarVisibilidadeDosComentarios(alternar.getAttribute('id-publicacao'))\r\n    })\r\n})\r\n\r\nconst alternarDescricao = document.querySelectorAll('.publicacao [alternar-visibiliadade-descricao]')\r\n\r\nfunction alternarVisibilidadeDaDescricao(idPublicacao, alternar) {\r\n    const descricao = document.querySelector(`.publicacao[id-publicacao=\"${idPublicacao}\"] .publicacao__descricao__conteudo`)\r\n    \r\n    if (descricao.classList.contains('ativado')) {\r\n        descricao.classList.remove('ativado')\r\n        alternar.innerText = 'Ver mais...'\r\n    } else {\r\n        descricao.classList.add('ativado')\r\n        alternar.innerText = 'Ver menos...'\r\n    }\r\n}\r\n\r\nalternarDescricao.forEach(alternar => {\r\n    alternar.addEventListener('click', () => {\r\n        alternarVisibilidadeDaDescricao(alternar.getAttribute('id-publicacao'), alternar)\r\n    })\r\n})\n\n//# sourceURL=webpack://molde/./frontend/js/feed.js?");

/***/ }),

/***/ "./frontend/scss/feed.scss":
/*!*********************************!*\
  !*** ./frontend/scss/feed.scss ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://molde/./frontend/scss/feed.scss?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	__webpack_modules__["./frontend/js/feed.js"](0, {}, __webpack_require__);
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./frontend/scss/feed.scss"](0, __webpack_exports__, __webpack_require__);
/******/ 	
/******/ })()
;