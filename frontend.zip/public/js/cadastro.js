/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./frontend/js/cadastro.js":
/*!*********************************!*\
  !*** ./frontend/js/cadastro.js ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _cadastro_cadastro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cadastro/cadastro */ \"./frontend/js/cadastro/cadastro.js\");\n/* harmony import */ var _cadastro_cadastro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_cadastro_cadastro__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _cadastro_selecaoCategoria__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cadastro/selecaoCategoria */ \"./frontend/js/cadastro/selecaoCategoria.js\");\n/* harmony import */ var _cadastro_selecaoCategoria__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_cadastro_selecaoCategoria__WEBPACK_IMPORTED_MODULE_1__);\n// JS\r\n\r\n\r\n\r\n//SCSS\r\n// import \"../scss/cadastro.scss\"\r\n\n\n//# sourceURL=webpack://molde/./frontend/js/cadastro.js?");

/***/ }),

/***/ "./frontend/js/cadastro/cadastro.js":
/*!******************************************!*\
  !*** ./frontend/js/cadastro/cadastro.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval("// desmoo/cadastro\r\n\r\nconst formulario = document.getElementById('formulario')\r\n\r\nconst botaoEnvio = document.getElementById('botaoEnvio')\r\n\r\nconst camposObrigatorios = document.querySelectorAll(\"[obrigatorio='true']\")\r\n\r\nconst campoNomeCompleto = document.getElementById('nomeCompleto')\r\nconst campoEmail = document.getElementById('email')\r\nconst campoCpf = document.getElementById('cpf')\r\nconst campoSenha = document.getElementById('senha')\r\nconst campoRepeticaoSenha = document.getElementById('repeticaoSenha')\r\nconst confirmacaoTermos = document.getElementById('confirmacaoTermos')\r\n\r\nconst { ValidacaoCpf } = __webpack_require__(/*! ./validacaoCpf */ \"./frontend/js/cadastro/validacaoCpf.js\");\r\n\r\nclass Validacao {\r\n    constructor(formulario, botaoEnvio, camposObrigatorios, campoNomeCompleto, campoEmail, campoCpf, campoSenha, campoRepeticaoSenha, confirmacaoTermos) {\r\n        this.formulario = formulario\r\n\r\n        this.botaoEnvio = botaoEnvio\r\n\r\n        this.camposObrigatorios = camposObrigatorios\r\n\r\n        this.campoNomeCompleto = campoNomeCompleto\r\n        this.campoEmail = campoEmail\r\n        this.campoCpf = campoCpf\r\n        this.campoSenha = campoSenha\r\n        this.campoRepeticaoSenha = campoRepeticaoSenha\r\n\r\n        this.confirmacaoTermos = confirmacaoTermos\r\n    }\r\n\r\n    cancelarEnvio() {\r\n        this.botaoEnvio.addEventListener('click', evento => {\r\n            evento.preventDefault()\r\n        })\r\n    }\r\n\r\n    permitirEnvio() {\r\n        this.botaoEnvio.addEventListener('click', () => {\r\n            formulario.submit()\r\n        })\r\n    }\r\n\r\n    obrigatoriosEstaoPreenchidos() {\r\n        let obrigatoriosEstaoPreenchidos = true \r\n\r\n        this.camposObrigatorios.forEach(campo => {\r\n            if (campo.value.length == 0) {\r\n                obrigatoriosEstaoPreenchidos = false\r\n                this.dispararErro(campo, '* Campo não pode estar em branco.')\r\n            }\r\n        })\r\n        \r\n        return obrigatoriosEstaoPreenchidos\r\n    }\r\n\r\n    validacaoSenha() {\r\n        let senhaValida = false\r\n\r\n        const caracteresEspeciais = []\r\n        const numeros = []\r\n        const maiusculas = []\r\n       \r\n        const senha = this.campoSenha.value.trim()\r\n\r\n        console.log(senha)\r\n\r\n        for (const caractere of senha) {\r\n            const codigoCaractere = caractere.charCodeAt(0)\r\n\r\n            if ((codigoCaractere >= 33 && codigoCaractere <= 47) || (codigoCaractere >= 58 && codigoCaractere <= 64) || (codigoCaractere >= 91 && codigoCaractere <= 96) || (codigoCaractere >= 123 && codigoCaractere <= 126) || (codigoCaractere >= 192 && codigoCaractere <= 197)) {\r\n                // caracteres especiais\r\n                caracteresEspeciais.push(caractere)\r\n            } \r\n            else if (codigoCaractere >= 48 && codigoCaractere <= 57) {\r\n                // numeros\r\n                numeros.push(caractere)\r\n            }\r\n            else if ((codigoCaractere >= 65 && codigoCaractere <= 90) || (codigoCaractere == 128) || (codigoCaractere >= 142 && codigoCaractere <= 144) || (codigoCaractere >= 153 && codigoCaractere <= 154) || codigoCaractere == 165 || (codigoCaractere >= 181 && codigoCaractere <= 183) || codigoCaractere == 199 || (codigoCaractere >= 209 && codigoCaractere <= 212) || (codigoCaractere >= 224 && codigoCaractere <= 229) || (codigoCaractere >= 233 && codigoCaractere <= 237)) {\r\n                // maiúsculas\r\n                maiusculas.push(caractere)\r\n            }\r\n        }\r\n\r\n        if (numeros.length >= 2) {\r\n            senhaValida = true\r\n        } else {\r\n            if (numeros.length < 2) {\r\n                this.dispararErro(this.campoSenha, '* Insira ao menos dois números.')\r\n            } \r\n        }\r\n\r\n        return senhaValida\r\n    }\r\n\r\n    validacaoEmail() {\r\n        let EmailValido = false\r\n\r\n        // verificando se há a presença de @ + provedor + .com. Se sim, irá retornar um array com duas posições\r\n        const gmail = this.campoEmail.value.split('@gmail.com')\r\n        const hotmail = this.campoEmail.value.split('@hotmail.com')\r\n        const yahoo = this.campoEmail.value.split('@yahoo.com')\r\n\r\n\r\n        if (gmail.length == 2 || hotmail.length == 2 || yahoo.length == 2) {\r\n            EmailValido = true\r\n        } else {\r\n            this.dispararErro(this.campoEmail, '* Verifique se preencheu o campo corretamente.')\r\n        }\r\n\r\n        return EmailValido\r\n    }\r\n\r\n    validacaoCPF() {\r\n        let cpfValido = false\r\n\r\n        const cpf = new ValidacaoCpf(this.campoCpf.value)\r\n\r\n        cpf.validar()\r\n\r\n        if (cpf.eValido) {\r\n            cpfValido = true\r\n        }\r\n        else {\r\n            this.dispararErro(this.campoCpf, '* CPF inválido.')\r\n        }\r\n\r\n        return cpfValido\r\n    }\r\n\r\n    dispararErro(campo, mensagem) {\r\n        const mensagemErro = document.createElement('div')\r\n        mensagemErro.innerHTML = mensagem\r\n        mensagemErro.classList.add('mensagem-de-erro')\r\n        campo.insertAdjacentElement('beforeBegin', mensagemErro)\r\n    }\r\n\r\n    // função responsável por remover todas as mensagens de erro\r\n    removerErros() {\r\n        const mensagensDeErro = document.querySelectorAll('.mensagem-de-erro')\r\n\r\n        mensagensDeErro.forEach(mensagemDeErro => mensagemDeErro.remove())\r\n    }\r\n\r\n    termoPreenchido() {\r\n        let termoPreenchido = this.confirmacaoTermos.checked\r\n\r\n        if (!termoPreenchido) this.dispararErro(this.confirmacaoTermos, '* !')\r\n\r\n        return termoPreenchido\r\n    }\r\n\r\n    senhasSaoIguais() {\r\n        let senhasSaoIguais = false\r\n\r\n        if (this.campoSenha.value == this.campoRepeticaoSenha.value) {\r\n            senhasSaoIguais = true\r\n        } else {\r\n            this.dispararErro(this.campoRepeticaoSenha, '* Senhas devem ser idênticas!')\r\n        }\r\n\r\n        return senhasSaoIguais\r\n    }\r\n\r\n    jaCadastrado() {\r\n        let jaCadastrado = false\r\n\r\n        this.camposObrigatorios.forEach(campoObrigatorio => {\r\n            if (campoObrigatorio.classList.contains('ja-cadastrado')) {\r\n                jaCadastrado = true\r\n\r\n                this.dispararErro(campoObrigatorio, '* Já cadastrado!')\r\n            }\r\n        })\r\n\r\n        return jaCadastrado\r\n    }\r\n\r\n    formatarCpf() {\r\n        let cpf = this.campoCpf.value\r\n\r\n        if (this.campoCpf.value.length == 3) {\r\n            cpf = this.campoCpf.value\r\n            this.campoCpf.value = `${cpf}.`\r\n        }\r\n\r\n        if (this.campoCpf.value.length == 7) {\r\n            cpf = this.campoCpf.value\r\n            this.campoCpf.value = `${cpf}.`\r\n        }\r\n\r\n        if (this.campoCpf.value.length == 11) {\r\n            cpf = this.campoCpf.value\r\n            this.campoCpf.value = `${cpf}-`\r\n        }\r\n    }\r\n\r\n    start() {\r\n        this.botaoEnvio.addEventListener('click', evento => {\r\n            evento.preventDefault()\r\n\r\n            this.removerErros()\r\n            \r\n            const obrigatoriosEstaoPreenchidos = this.obrigatoriosEstaoPreenchidos()\r\n            const emailValido = this.validacaoEmail()\r\n            const cpfValido = this.validacaoCPF()\r\n            const senhaValida = this.validacaoSenha()\r\n            const senhasSaoIguais = this.senhasSaoIguais()\r\n            const termoPreenchido = this.termoPreenchido()\r\n            const jaCadastrado = this.jaCadastrado()\r\n\r\n            if (obrigatoriosEstaoPreenchidos && emailValido && cpfValido && senhaValida && senhasSaoIguais && termoPreenchido && !jaCadastrado) {\r\n                this.formulario.submit()\r\n            }\r\n        })\r\n\r\n        this.campoCpf.addEventListener('keyup', () => {\r\n            this.formatarCpf()\r\n        })\r\n    }\r\n}\r\n\r\nconst v1 = new Validacao(formulario, botaoEnvio, camposObrigatorios, campoNomeCompleto, campoEmail, campoCpf, campoSenha, campoRepeticaoSenha, confirmacaoTermos)\r\nv1.start()\n\n//# sourceURL=webpack://molde/./frontend/js/cadastro/cadastro.js?");

/***/ }),

/***/ "./frontend/js/cadastro/selecaoCategoria.js":
/*!**************************************************!*\
  !*** ./frontend/js/cadastro/selecaoCategoria.js ***!
  \**************************************************/
/***/ (function() {

eval("// formulário da página \"tipo de categoria\"\r\nconst formTipoDeCategoria = document.getElementById('formTipoDeCategoria')\r\n\r\n// referente aos cards propriamente ditos\r\nconst cardsTipoDeCategoria = document.querySelectorAll('label')\r\n\r\ncardsTipoDeCategoria.forEach(card => {\r\n    card.addEventListener('click', () => {\r\n        setTimeout(() => {\r\n            formTipoDeCategoria.submit()\r\n        }, 100)\r\n    })\r\n})\n\n//# sourceURL=webpack://molde/./frontend/js/cadastro/selecaoCategoria.js?");

/***/ }),

/***/ "./frontend/js/cadastro/validacaoCpf.js":
/*!**********************************************!*\
  !*** ./frontend/js/cadastro/validacaoCpf.js ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, exports) {

eval("// 705.484.450-52\r\n// 070.987.720-03\r\n\r\nconst _eValido = Symbol('validateStatus')\r\n\r\nclass ValidacaoCpf {\r\n    constructor (cpfRecebido) {\r\n        this[_eValido] = false\r\n        this.cpfRecebido = cpfRecebido\r\n        Object.defineProperty(this, 'cpfLimpo', {\r\n            configurable: false,\r\n            enumerable: true,\r\n            writable: false,\r\n            value: cpfRecebido.replace(/\\D+/g, ''),\r\n            // nodemailer\r\n        })\r\n    }\r\n\r\n    estaNaSequencia() {\r\n        return this.cpfLimpo.charAt(0).repeat(this.cpfLimpo.length) == this.cpfLimpo\r\n    }\r\n\r\n    gerarNovoCpf() {\r\n         const cpfIncompleto = this.cpfLimpo.slice(0, -2)\r\n         const digito1 = ValidacaoCpf.gerarDigito(cpfIncompleto)\r\n         const digito2 = ValidacaoCpf.gerarDigito(cpfIncompleto + digito1)\r\n\r\n         return cpfIncompleto + digito1 + digito2 \r\n    }\r\n        \r\n    static gerarDigito(cpfIncompleto) {\r\n            let digito\r\n            let total = 0\r\n            let contadorReverso = cpfIncompleto.length + 1\r\n            \r\n            for (let caractere of cpfIncompleto) {\r\n                total += contadorReverso * Number(caractere)\r\n                contadorReverso--\r\n            }\r\n\r\n            digito = 11 - (total % 11)\r\n\r\n            return digito <= 9 ? String(digito) : '0'\r\n    }\r\n\r\n    validar() {\r\n        if (!this.cpfLimpo) return false\r\n        if (typeof this.cpfLimpo !== 'string') return false \r\n        if (this.cpfLimpo.length !== 11) return false\r\n        if (this.estaNaSequencia()) return false\r\n        if (this.gerarNovoCpf() !== this.cpfLimpo) return false\r\n\r\n        this[_eValido] = true\r\n\r\n        return true\r\n    }\r\n\r\n    get eValido() {\r\n        return this[_eValido]\r\n    }\r\n}\r\n\r\nexports.ValidacaoCpf = ValidacaoCpf;\n\n//# sourceURL=webpack://molde/./frontend/js/cadastro/validacaoCpf.js?");

/***/ }),

/***/ "./frontend/scss/cadastro.scss":
/*!*************************************!*\
  !*** ./frontend/scss/cadastro.scss ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://molde/./frontend/scss/cadastro.scss?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	__webpack_require__("./frontend/js/cadastro.js");
/******/ 	var __webpack_exports__ = __webpack_require__("./frontend/scss/cadastro.scss");
/******/ 	
/******/ })()
;