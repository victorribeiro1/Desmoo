/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./frontend/js/solicitacoes.js":
/*!*************************************!*\
  !*** ./frontend/js/solicitacoes.js ***!
  \*************************************/
/***/ (function() {

eval("const botoes = document.querySelectorAll('button')\r\nbotoes.forEach(botao => {\r\n    botao.addEventListener('click', e => {\r\n        e.preventDefault()\r\n\r\n        const id = botao.getAttribute('id-usuario')\r\n        console.log(id)\r\n        let situacao = botao.innerText.toLowerCase()\r\n\r\n        situacao = situacao == \"aceitar\" ? \"aceito\" : \"recusado\"\r\n\r\n        preencherInput(id, situacao)\r\n        enviarForms(id)\r\n    })\r\n})\r\n\r\nfunction preencherInput(id, situacao) {\r\n    const input = document.querySelector(`input[id-usuario='${id}']`)\r\n    input.setAttribute('value', situacao)\r\n}\r\n\r\nfunction enviarForms(id) {\r\n    document.querySelector(`form[id-usuario='${id}']`).submit()\r\n}\n\n//# sourceURL=webpack://molde/./frontend/js/solicitacoes.js?");

/***/ }),

/***/ "./frontend/scss/solicitacoes.scss":
/*!*****************************************!*\
  !*** ./frontend/scss/solicitacoes.scss ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://molde/./frontend/scss/solicitacoes.scss?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	__webpack_modules__["./frontend/js/solicitacoes.js"](0, {}, __webpack_require__);
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./frontend/scss/solicitacoes.scss"](0, __webpack_exports__, __webpack_require__);
/******/ 	
/******/ })()
;